import boto3 
# setup the SQS Service
sqs = boto3.resource('sqs')

# Create the queue
queue = sqs.create_queue(QueueName='My_SQS')

# Print the queue url
print(queue.url)


